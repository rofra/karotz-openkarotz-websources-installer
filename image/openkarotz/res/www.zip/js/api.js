var kused = -1;
var uused = -1;

// ----------------------------
$(document).ready(
function(){

Init();	
	
	// Load Tabs Content
	$('#Infos').load('infos.html');
	$('#State').load('state.html');
	$('#Leds').load('leds.html');
	$('#Ears').load('ears.html');
	$('#Rfid').load('rfid.html');
	$('#TTS').load('tts.html');
	$('#Sounds').load('sounds.html');	
  	$('#Pictures').load('pictures.html');
	$('#Apps').load('apps.html');
	$('#Update').load('update.html');
	$('#Docs').load('about.html');
	
	// Load Dialog
	$('#Dialog').load('dialog.html');			
 
$("#tabs").tabs({
 activate: function(event, ui) {
	 	$("#json_result").val("");
 
     	if ( ui.newPanel.attr('id') == "Infos" ) 	{ InitGauge(); }
		if ( ui.newPanel.attr('id') == "Pictures" ) { loadImage( "/images/mire.jpg", 160, 120, '#img_snapshot'); }			
	    if ( ui.newPanel.attr('id') == "Rfid" ) 	{ RefreshTagList(); }
		if ( ui.newPanel.attr('id') == "TTS" )  	{ RefreshVoiceList();}	
		if ( ui.newPanel.attr('id') == "Sounds")	{ RefreshSoundList(); RefreshRadioList();}
		if ( ui.newPanel.attr('id') == "Update")	{ CheckUpdate();  CheckPatch();}
		if ( ui.newPanel.attr('id') == "Apps")		{
			 CheckAppsInstallation( "apps.clock.install", "#funny_clock" );
			 CheckAppsInstallation( "apps.moods.install", "#moods" );
			 RefreshAppsList();
			 RefreshMoodsList();
			 RefreshStoriesList();
		}


		
		
		CheckUpdate}							  							
});
	
	$("#btn_update_scripts").on('click', function ()
	{
		window.open("/cgi-bin/update?force=1")		
	});

	
});

