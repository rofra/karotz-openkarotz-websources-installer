// ----------------------------
// General Functions
// ----------------------------

function Init()
{	
	var kkeys = [], konami = "38,38,40,40,37,39,37,39,66,65";
	$(document).keydown(function(e) {
	  kkeys.push( e.keyCode );
	  if ( kkeys.toString().indexOf( konami ) >= 0 ){
		$(document).unbind('keydown',arguments.callee);
		window.location.href = '/tools.html';
	
	  }
	});
	
	InitGauge();
		
	$( document ).tooltip();
	$("#json_result").width = $(window).width();   	
	$("#json_title").on('click', function () { $("#json_result").val(""); });
	
	// Set global json options
	$.getJSON("/cgi-bin/get_version", function(data) {
		document.title = "OPEN-KAROTZ - Version " + data.version;
	});	

	
	$.ajaxSetup({ timeout: 40000 });
	$.ajaxSetup({ cache: false });
	$.ajaxSetup({"error":function(jqXHR, textStatus, errorThrown) {
		 $("#json_result").val("HTTP Error : " + jqXHR.status + "  " + errorThrown + " " + jqXHR.url);
		 $.unblockUI(); 
		 }
	});

	$.ajaxSetup({ beforeSend: function(jqXHR, settings) { jqXHR.url = settings.url;}
	});
}	

	

function CapitaliseFirstLetter(string)
{
    return string.charAt(0).toUpperCase() + string.slice(1);
}

function loadImage(path, width, height, target) 
{
    $('<img src="'+ path +'">').load(function() {
	$("#snapshot_filename").text(path);
	//document.getElementById('resultAreaID_1').innerHTML = "<img src="+imagePath +" onload='fnCallback_1()'>";
	//$('#img_snapshot')
	//document.getElementById('#img_snapshot').innerHTML('<div><img src="' + path + '" width=160 height=120 title="' + path + '"/></div>');
	var img = new Image();
	img.src =path ;
	img.width=160;
	img.height=120;
	img.border=2;
	img.title="Click to see full size image";
	$("#img_snapshot").hide();
	$("#img_snapshot").empty();
    $("#img_snapshot").append(img);
	$("#img_snapshot").show();		
    });
}


function CheckUpdate()
{
	// $.getJSON( "http://karotz.filippi.org/2.0/update.json", function(data) 
	$('#cbx_update').empty();
	$('#cbx_update').prop("disabled", true );
	$('#cbx_update').append('<option value="-1">Loading Update(s) ...</option>');
	$("#btn_install_update").prop("disabled", true );    
		$.getJSON("/cgi-bin/ajax_proxy?url=/2.0/update.json", function(data) 
		{
			if ( parseInt(data.return) == 0)
			{
				if ( data.updates.length == 0 )
				{
					$('#cbx_update').empty();
					$('#cbx_update').append('<option value=\'{"id":"","file":""}\'">No patch available...</option>');	
				}
				else
				{
					$('#cbx_update').prop("disabled", false )
					$("#btn_install_update").prop("disabled", false );

					$('#cbx_update')[0].options.length = 0;
					for (var i = 0; i < data.updates.length; i++)
					{
						$('#cbx_update').append('<option value=\'{"id":"' + data.updates[i].id + '","file":"' + data.updates[i].file + '"}\'>' + data.updates[i].name  + '</option>');					
					}				
				}
			}
			else
			{
				$('#cbx_update').empty();
				$('#cbx_update').append('<option value="-1">No update available...</option>');
			}
			
		});	
	$('#cbx_update').focus()

}

function CheckPatch()
{
	$('#cbx_patch').empty();
	$('#cbx_patch').prop("disabled", true );
	$('#cbx_patch').append('<option value="-1">Loading Patchs(s) ...</option>');
	$("#btn_install_patch").prop("disabled", true );    
		$.getJSON("/cgi-bin/ajax_proxy?url=/2.0/patch.json", function(data) 
		{
			if ( parseInt(data.return) == 0)
			{
				if ( data.patchs.length == 0 )
				{
					$('#cbx_patch').empty();
					$('#cbx_patch').append('<option value=\'{"id":"","file":""}\'">No patch available...</option>');	
				}
				else
				{
					$('#cbx_patch').prop("disabled", false )
					$("#btn_install_patch").prop("disabled", false );

					$('#cbx_patch').empty();
					for (var i = 0; i < data.patchs.length; i++)
					{
						$('#cbx_patch').append('<option value=\'{"id":"' + data.patchs[i].id + '","file":"' + data.patchs[i].file + '"}\'>' + data.patchs[i].name  + '</option>');					
					}				
				}
			}
			else
			{
				$('#cbx_patch').empty();
				$('#cbx_patch').append('<option value="-1">No patch available...</option>');
			}
			
		});	
	$('#cbx_patch').focus()

}
	

function CheckAppsInstallation( u, t )
{
  bInstalled=false;
 
	$.getJSON( "/cgi-bin/" + u +"?check=1", function(data) 
	{
		if ( parseInt(data.return) == 0)
		{
			if ( parseInt(data.enabled) == 1 )
			{ $(t).removeClass( "ui-state-disabled" ); }	
			else
			{ $(t).addClass( "ui-state-disabled" ); }
		}
	});
}


function RefreshAppsList()
{
	$('#cbx_apps').empty();
	$('#cbx_apps').prop("disabled", true );
	$('#cbx_apps').append('<option value="-1">Loading application(s) list ...</option>');
	$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;Reading tag(s) list'});
	    
		$.getJSON("/cgi-bin/ajax_proxy?url=/2.0/apps.json", function(data) 
		{
			if ( parseInt(data.return) == 0)
			{
				if ( data.apps.length == 0 )
				{
					$('#cbx_apps').empty();
					$('#cbx_apps').prop("disabled", true );
					$('#cbx_apps').append('<option value="-1">No applications ...</option>');
	
					//$("#btn_delete_tag").prop("disabled", true );
					//$("#btn_unassign_tag").prop("disabled", true )
					//$("#btn_rfid_vera").prop("disabled", true )
					//$("#btn_rfid_eedomus").prop("disabled", true )
					//$("#btn_rfid_url").prop("disabled", true )
				}
				else
				{
					$('#cbx_apps').prop("disabled", false )
					//$("#btn_delete_tag").prop("disabled", false );
					//$("#btn_unassign_tag").prop("disabled", false )
					//$("#btn_rfid_vera").prop("disabled", false )
					//$("#btn_rfid_eedomus").prop("disabled", false )
					//$("#btn_rfid_url").prop("disabled", false )

					$('#cbx_apps')[0].options.length = 0;
					for (var i = 0; i < data.apps.length; i++)
					{
						$('#cbx_apps').append('<option value="'+ data.apps[i].file +'">'+ CapitaliseFirstLetter(data.apps[i].id ) + '</option>');					
					}				
				}
			}
			$.unblockUI();
		});	
		$.unblockUI();	
		$('#cbx_apps').focus()
}


function RefreshRadioList()
{
	$('#cbx_stream').empty();
	$('#cbx_stream').prop("disabled", true );
	$('#cbx_stream').append('<option value="-1">Loading streams ...</option>');
$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;Reading tag(s) list'});
	    
		$.getJSON("/cgi-bin/radios_list", function(data) 
		{
			if ( parseInt(data.return) == 0)
			{
				if ( data.streams.length == 0 )
				{
					$('#cbx_stream').empty();
					$('#cbx_stream').prop("disabled", true );
					$('#cbx_stream').append('<option value="-1">No Streams ...</option>');
	
					$("#btn_sound_play").prop("disabled", true );
					$("#btn_sound_pause").prop("disabled", true )
					$("#btn_sound_stop").prop("disabled", true )
				}
				else
				{
					$('#cbx_stream').prop("disabled", false )
					$("#btn_sound_play").prop("disabled", false );
					$("#btn_sound_pause").prop("disabled", false )
					$("#btn_sound_stop").prop("disabled", false )
	
					$('#cbx_stream')[0].options.length = 0;
					for (var i = 0; i < data.streams.length; i++)
					{
						$('#cbx_stream').append('<option value="'+ data.streams[i].url +'">'+data.streams[i].name +'</option>');					
					}				
				}
			}
			$.unblockUI();
		});	
		$.unblockUI();	
		$('#cbx_stream').focus()	
}	


function RefreshTagList()
{
	$('#cbx_tags4').empty();
	$('#cbx_tags4').prop("disabled", true );
	$('#cbx_tags4').append('<option value="-1">Loading Tags ...</option>');
	$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;Reading tag(s) list'});
	    
		$.getJSON("/cgi-bin/rfid_list_ext", function(data) 
		{
			if ( parseInt(data.return) == 0)
			{
				if ( data.tags.length == 0 )
				{
					$('#cbx_tags4').empty();
					$('#cbx_tags4').prop("disabled", true );
					$('#cbx_tags4').append('<option value="-1">No Tags ...</option>');
	
					$("#btn_delete_tag").prop("disabled", true );
					$("#btn_unassign_tag").prop("disabled", true )
					$("#btn_rfid_vera").prop("disabled", true )
					$("#btn_rfid_eedomus").prop("disabled", true )
					$("#btn_rfid_url").prop("disabled", true )
				}
				else
				{
					$('#cbx_tags4').prop("disabled", false )
					$("#btn_delete_tag").prop("disabled", false );
					$("#btn_unassign_tag").prop("disabled", false )
					$("#btn_rfid_vera").prop("disabled", false )
					$("#btn_rfid_eedomus").prop("disabled", false )
					$("#btn_rfid_url").prop("disabled", false )

					$('#cbx_tags4')[0].options.length = 0;
					for (var i = 0; i < data.tags.length; i++)
					{
						$('#cbx_tags4').append('<option value="'+ data.tags[i].id +'">'+data.tags[i].type_name+"&nbsp;"+data.tags[i].color_name+" - " + data.tags[i].id +'</option>');					
					}				
				}
			}
			$.unblockUI();
		});	
		$.unblockUI();	
		$('#cbx_tags4').focus()
}
	

function SendCommandApps( cmd, message )
{
	$.ajaxSetup({ timeout: 60000 });
	$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;' + message + '</H2>' })
	
	$("#json_result").val("");
	$.get("/cgi-bin/"+cmd, function(data) {
	$("#json_result").val(data); 
	
	CheckAppsInstallation( "apps.clock.install", "#funny_clock" );
	CheckAppsInstallation( "apps.moods.install", "#moods" );
	
	$.ajaxSetup({ timeout: 40000 });
    $.unblockUI();
	});
}


function SendCommand( cmd, message, noblock )
{
	if ( typeof noblock == 'undefined' )
	{
		$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;' + message + '</H2>' })
	}
	
	$("#json_result").val("");
	$.get("/cgi-bin/"+cmd, function(data) {
	if ( typeof noblock == 'undefined' )
	{
		$.unblockUI();
	}
	
	$("#json_result").val(data); });
}

function SendCommandJSON( cmd, message )
{
		$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;' + message + '</H2>' })
		$("#json_result").val("");
		$.getJSON("/cgi-bin/"+cmd, function(data) 
		{
			$.unblockUI();
			$("#json_result").val(data);
		});
}

function InitGauge()
{
		$("#json_result").val("");
		$.getJSON("/cgi-bin/get_free_space", function(data) 
		{
			kused=parseInt(data.karotz_percent_used_space);
			uused=parseInt(data.usb_percent_used_space);
			
			//alert ( kused );
			if ( kused > -1 )
			{
				$( "#internal_storage" ).removeClass( "ui-state-disabled" );
				$('#gaugeContainer').jqxGauge('value', kused );
				$('#gaugeValue').text( "Used Space: " + kused + ' %')
			}
			
			if ( uused > -1 )
			{
				$('#gaugeContainer2').jqxGauge('value', uused );
				$('#gaugeValue2').text( "Used Space: " + uused + ' %')
				$( "#usb_storage" ).removeClass( "ui-state-disabled" );
			}
			// alert( kused );
		});
}


function TakePicture( cmd )
{
		$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;Taking Picture</H2>' })
		$("#json_result").val("");		
		$.getJSON("/cgi-bin/"+cmd, function(data,textStatus,jqXHR) 
		{
			$.unblockUI();
			// $("#img_snapshot").attr("href", "/Snapshots/" + data.thumb );
			fn = "/Snapshots/" + data.thumb;
			$("#snapshot_filename").attr({ title : fn });
		  
			//$("#snapshot_filename").text("/snapshots/" + data.filename);
			   loadImage( "/snapshots/" + data.filename, 160, 120, '#img_snapshot');
	
			// $('#img_snapshot').html('<img src="/Snapshots/snapshot_2013_09_29_00_18_21.jpg" width=100 height=100/>');
			$("#json_result").val(jqXHR.responseText);
		});
}


function RefreshVoiceList()
{
	$('#cbx_voice').empty();
	$('#cbx_voice').prop("disabled", true );
	$('#cbx_voice').append('<option value="-1">No voice</option>');
	$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;Reading voice list'});
		$.getJSON("/cgi-bin/voice_list", function(data) 
		{
			if ( parseInt(data.return) == 0)
			{
				if ( data.voices.length == 0 )
				{
					$('#cbx_voice').prop("disabled", true );
				}
				else
				{
					$('#cbx_voice').empty();
					$('#cbx_voice')[0].options.length = 0;
					$('#cbx_voice').prop("disabled", false )
					for (var i = 0; i < data.voices.length; i++)
					{
						$('#cbx_voice').append('<option value="'+ data.voices[i].id +'">'+ CapitaliseFirstLetter(data.voices[i].id) +'</option>');					
					}				
				}
			}
		});
			
		$.unblockUI();	
		$('#cbx_voice').focus();
}

 
// cbx moods
function RefreshMoodsList()
{
	$('#cbx_moods').empty();
	$('#cbx_moods').prop("disabled", true );
	$('#cbx_moods').append('<option value="-1">Loading Moods ...</option>');
	$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;Reading mood(s) list'});
	    
		$.getJSON("/cgi-bin/moods_list", function(data) 
		{
			if ( parseInt(data.return) == 0)
			{
				if ( data.moods.length == 0 )
				{
					$('#cbx_moods').empty();
					$('#cbx_moods').append('<option value="5">No Moods</option>');
					$('#cbx_moods').prop("disabled", true );
					
				}
				else
				{
					$('#cbx_moods')[0].options.length = 0;
	
					$('#cbx_moods').prop("disabled", false )
					for (var i = 0; i < data.moods.length; i++)
					{
						Description = data.moods[i].text;	
						$('#cbx_moods').append('<option value="'+ data.moods[i].id +'">'+ Description + '</option>');					
					}				
				}
			}
			else
			{
				$('#cbx_moods').empty();
				$('#cbx_moods').append('<option value="5">No Moods</option>');
			}
			$.unblockUI();
		});	
		$.unblockUI();	
		$('#cbx_moods').focus()
}

// cbx_stories
function RefreshStoriesList()
{
	$('#cbx_stories').empty();
	$('#cbx_stories').prop("disabled", true );
	$('#cbx_stories').append('<option value="5">No stories</option>');
	$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;Reading sound list'});
		$.getJSON("/cgi-bin/stories_list", function(data) 
		{
			if ( parseInt(data.return) == 0 )
			{
				if ( data.stories.length == 0 )
				{
					$('#cbx_stories').prop("disabled", true );
				}
				else
				{
					$('#cbx_stories').empty();
					$('#cbx_stories')[0].options.length = 0;
					$('#cbx_stories').prop("disabled", false )
					for (var i = 0; i < data.stories.length; i++)
					{
						$('#cbx_stories').append('<option value="'+ data.stories[i].id +'">'+ CapitaliseFirstLetter(data.stories[i].name) +'</option>');					
					}				
				}
			}
		});
			
		$.unblockUI();	
		$('#cbx_stories').focus();
}



function RefreshSoundList()
{
	$('#cbx_sound').empty();
	$('#cbx_sound').prop("disabled", true );
	$('#cbx_sound').append('<option value="-1">No sound</option>');
	$.blockUI({ message: '<H2><img src="/images/ajax-loader.gif" />&nbsp;Reading sound list'});
		$.getJSON("/cgi-bin/sound_list", function(data) 
		{
			if ( parseInt(data.return) == 0)
			{
				if ( data.sounds.length == 0 )
				{
					$('#cbx_sound').prop("disabled", true );
				}
				else
				{
					$('#cbx_sound').empty();
					$('#cbx_sound')[0].options.length = 0;
					$('#cbx_sound').prop("disabled", false )
					for (var i = 0; i < data.sounds.length; i++)
					{
						$('#cbx_sound').append('<option value="'+ data.sounds[i].id +'">'+ CapitaliseFirstLetter(data.sounds[i].id) +'</option>');					
					}				
				}
			}
		});
			
		$.unblockUI();	
		$('#cbx_sound').focus();
}


function LoadMoods( MoodsId)
{
  var result;
  $.ajax(
  {
	type: 'GET',
	//async: true,
	url:  '/cgi-bin/get_file?src=usbkey/Moods/fr/' + MoodsId + '.mp3&dest=Apps/Moods/fr/' +  MoodsId +'.mp3',
	success: function(data) {
		result = data;
	}
  });
  return result;
}
