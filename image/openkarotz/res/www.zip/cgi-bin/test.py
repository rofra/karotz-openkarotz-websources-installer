#!/usr/bin/python
# -*- coding:Utf-8 -*
print "Content-Type: multipart/x-mixed-replace; boundary=--jpgboundary\n"

import cgi
import cgitb; cgitb.enable(display=1, logdir='/tmp')
import subprocess
import os
import time

if __name__ == '__main__':
        takeSnapshot = 'dbus-send --system --type=method_call --print-reply --dest=com.mindscape.karotz.Webcam /com/mindscape/karotz/Webcam com.mindscape.karotz.KarotzInterface.takeSnapshot string:1 string:"file" int32:0'
        while (1):
                if (not os.path.isfile("/tmp/picture.jpg") or (time.time() - os.path.getmtime("/tmp/picture.jpg") > 10)):
                        os.system(takeSnapshot)
                print "--jpgboundary\n"
                print "Content-Type: image/jpeg\n"
                print open("/tmp/picture.jpg", "rb").read()

                time.sleep(5)
